/*
 * GccApplication5.c
 *
 * Created: 2/6/2022 3:23:22 PM
 * Author : Noor Rabie
 */
#define F_CPU 16000000
#include "BIT_MATH.h"
#include "STD.h"
#include "DC_MOTOR.h"
#include "UART.h"
#include "DIO.h"
#include "DC_MOTOR_CFG.h"
#include "LCD.h"
#include <util/delay.h>

extern u8 Reading;



int main(void){
	DC_MOTOR_INIT();
	UART_INIT();
	LCD_INIT();

	while (1)
	{
		if (Reading == 'R' )
		{
			LEFT_MOTOR_DIRECTION(CLK_WISE);
			LCD_GO_TO(0,0);
			LCD_WRITE_CHR(Reading);
		} 
		else if(Reading == 'L')
		{
			RIGHT_MOTOR_DIRECTION(CLK_WISE);
			LCD_GO_TO(0,0);
			LCD_WRITE_CHR(Reading);		
		}
		else if(Reading == 'F')
		{
			CAR_FORWARD();
			LCD_GO_TO(0,0);
			LCD_WRITE_CHR(Reading);
		}
		else if(Reading == 'B')
		{
		PIN_WRITE(DC_MOTOR_DIRECTION_PIN_3,HIGH);
		PIN_WRITE(DC_MOTOR_DIRECTION_PIN_4,LOW);
		PIN_WRITE(DC_MOTOR_DIRECTION_PIN_1,HIGH);
		PIN_WRITE(DC_MOTOR_DIRECTION_PIN_2,LOW);
			LCD_GO_TO(0,0);
			LCD_WRITE_CHR(Reading);
		}
				else if(Reading == 'B')
		{
		PIN_WRITE(DC_MOTOR_DIRECTION_PIN_3,HIGH);
		PIN_WRITE(DC_MOTOR_DIRECTION_PIN_4,LOW);
		PIN_WRITE(DC_MOTOR_DIRECTION_PIN_1,HIGH);
		PIN_WRITE(DC_MOTOR_DIRECTION_PIN_2,LOW);
			LCD_GO_TO(0,0);
			LCD_WRITE_CHR(Reading);
		}
		else if(Reading == 'S')
		{
			CAR_STOP();
			LCD_GO_TO(0,0);
			LCD_WRITE_CHR(Reading);
		}
		else
		{
			LCD_GO_TO(0,0);
			LCD_WRITE_CHR('N');
		}

    }
}