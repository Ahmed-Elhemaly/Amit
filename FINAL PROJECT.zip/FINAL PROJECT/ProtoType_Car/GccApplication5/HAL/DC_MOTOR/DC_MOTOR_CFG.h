﻿/*
 * DC_MOTOR_CFG.h
 *
 * Created: 31/12/2021 03:42:35 م
 *  Author: dell
 */ 


#ifndef DC_MOTOR_CFG_H_
#define DC_MOTOR_CFG_H_

#define DC_MOTOR_EN1                 PD4
#define DC_MOTOR_EN2                 PD5
#define DC_MOTOR_DIRECTION_PIN_1     PC3
#define DC_MOTOR_DIRECTION_PIN_2     PC4
#define DC_MOTOR_DIRECTION_PIN_3     PC5 
#define DC_MOTOR_DIRECTION_PIN_4     PC6


#endif /* DC_MOTOR_CFG_H_ */