﻿/*
 * HC_05_CFG.h
 *
 * Created: 30/11/2021 07:06:37 م
 *  Author: dell
 */ 


#ifndef HC_05_CFG_H_
#define HC_05_CFG_H_





#endif /* HC_05_CFG_H_ */