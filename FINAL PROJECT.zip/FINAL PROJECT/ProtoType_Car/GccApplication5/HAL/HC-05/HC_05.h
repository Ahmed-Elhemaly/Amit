﻿/*
 * HC_05.h
 *
 * Created: 30/11/2021 07:06:24 م
 *  Author: dell
 */ 


#ifndef HC_05_H_
#define HC_05_H_

#include "STD.h"

void HC_05_INIT(void);
void HC_05_SEND_BYTE(u8);
void HC_05_SEND_STRING(u8*);
u8   HC_05_REC_BYTE(void);
u8*  HC_05_REC_STRING(void);
#endif /* HC_05_H_ */