/*
 * BLUETOOTH_TEST.c
 *
 * Created: 2/16/2022 6:51:27 PM
 * Author : Noor Rabie
 */ 
#define F_CPU 16000000
#include "UART.h"
#include "DIO.h"
#include <util/delay.h>
#include "ADC.h"
int main(void)
{
	u16 POINTER = 0;
	u16 MIDDLE_FINGER =0;
	u16 RING_FINGER =0;
	u16 PINKY =0;
	
	u16 Forward_Check = 1;
	u16 Backward_Check = 1;
	u16 Right_Check = 1;
	u16 Left_Check = 1;
	u16 Stop_Check = 1;
	ADC_INIT();
	UART_INIT();
	_delay_ms(100);
	while(1)
	{
		POINTER = ADC_READ(4);
		_delay_ms(100);
		MIDDLE_FINGER = ADC_READ(5);
		_delay_ms(100);
		RING_FINGER = ADC_READ(6);
		_delay_ms(100);
		PINKY = ADC_READ(7);
		_delay_ms(100);
		
		if ((POINTER > 100) && (MIDDLE_FINGER < 100) && (RING_FINGER < 130) && (PINKY < 120) && (Forward_Check == 1))
		{
			UART_SEND('F');
			_delay_ms(50);
			Forward_Check = 0;
			Backward_Check = 1;
			Right_Check = 1;
			Left_Check = 1;
			Stop_Check = 1;
		}
		else if ((POINTER < 100) && (MIDDLE_FINGER > 100) && (RING_FINGER < 130) && (PINKY < 120) && (Backward_Check == 1))
		{
			UART_SEND('B');
			_delay_ms(50);
			Forward_Check = 1;
			Backward_Check = 0;
			Right_Check = 1;
			Left_Check = 1;
			Stop_Check = 1;
		}
		else if ((POINTER < 100) && (MIDDLE_FINGER < 100) && (RING_FINGER > 130) && (PINKY < 120) && (Right_Check == 1))
		{
			UART_SEND('R');
			_delay_ms(50);
			Forward_Check = 1;
			Backward_Check = 1;
			Right_Check = 0;
			Left_Check = 1;
			Stop_Check = 1;
		}
		else if ((POINTER < 100) && (MIDDLE_FINGER < 100) && (RING_FINGER < 130) && (PINKY > 120) && (Left_Check == 1))
		{
			UART_SEND('L');
			_delay_ms(50);
			Forward_Check = 1;
			Backward_Check = 1;
			Right_Check = 1;
			Left_Check = 0;
			Stop_Check = 1;
		}
		else if ((POINTER > 100) && (MIDDLE_FINGER > 100) && (RING_FINGER > 130) && (PINKY > 120) && (Stop_Check == 1))
		{
			UART_SEND('S');
			_delay_ms(50);
			Forward_Check = 1;
			Backward_Check = 1;
			Right_Check = 1;
			Left_Check = 1;
			Stop_Check = 0;
		}
		else
		{
			
		}
	}
}


