﻿/*
 * UART_CFG.h
 *
 * Created: 01/01/2022 04:16:24 م
 *  Author: dell
 */ 


#ifndef UART_CFG_H_
#define UART_CFG_H_





#endif /* UART_CFG_H_ */